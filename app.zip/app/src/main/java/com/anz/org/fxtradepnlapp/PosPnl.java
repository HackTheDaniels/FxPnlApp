package com.anz.org.fxtradepnlapp;

/**
 * Created by dell on 8/21/2016.
 */
public class PosPnl
{
    public int Id;
    public String Ccy;
    public double Pos;
    public double PosUsd;
    public int Age;
    public double Pnl;
    public double MarketBid;
    public double BookBid;
    public Boolean Starred;
}
