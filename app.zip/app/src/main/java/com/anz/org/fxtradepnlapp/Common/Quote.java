package com.anz.org.fxtradepnlapp.Common;

import java.util.Date;

/**
 * Created by dell on 8/18/2016.
 */
public class Quote
{
    public String BaseCcy;
    public String QuoteCcy;
    public String MarketType;
    public double BidPrice;
    public double AskPrice;
    public double MidPrice; // Not sure whether to have it or not.
    public Date QuoteDate;
}
