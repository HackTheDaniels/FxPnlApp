package com.anz.org.fxtradepnlapp.Common;

import java.util.Date;

/**
 * Created by dell on 8/18/2016.
 */
public class Deal
{
    public Date Date;
    public String BaseCcy;
    public String DealCcy;
    public int Quantity;
    public boolean Buy;
    public double Price;
}
