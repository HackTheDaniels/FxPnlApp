package com.anz.org.fxtradepnlapp.Common;

import java.util.Date;

/**
 * Created by dell on 8/21/2016.
 */
public class PosPnl
{
    public int Id;
    public String Ccy;
    public double Pos;
    public double PosUsd;
    public int Age;
    public double Pnl;
    public double MarketMid;
    public double BookMid;
    public Boolean Starred;
    public Date Timestamp;
}
