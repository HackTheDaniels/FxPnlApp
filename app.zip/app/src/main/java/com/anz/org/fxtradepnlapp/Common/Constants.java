package com.anz.org.fxtradepnlapp.Common;

/**
 * Created by dell on 8/19/2016.
 */
public class Constants
{
    public static final String APPNAME = "FxApp";
}
